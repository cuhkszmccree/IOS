//
//  ViewController.swift
//  LoginApp
//
//  Created by Ashisish on 11/6/20.
//

import UIKit
import Firebase
import SwiftSpinner

class ViewController: UIViewController {
    
    @IBOutlet weak var txtPassword: UITextField!
    
    
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var lblStatus: UILabel!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    @IBAction func loginAction(_ sender: Any) {
        
        let email = txtEmail.text
        let password = txtPassword.text
        
        if email == "" || password!.count < 6 {
            lblStatus.text = "Please enter email and correct password"
            return
        }
        if email?.isEmail == false {
            lblStatus.text = "Please enter valid e mail"
            return
        }
        
        SwiftSpinner.show("Logging in...")
        Auth.auth().signIn(withEmail: email!, password: password!) { [weak self] authResult, error in
            SwiftSpinner.hide()
            guard let strongSelf = self else { return }
            
            if error != nil {
                strongSelf.lblStatus.text = error?.localizedDescription
                return
            }
            
            self?.txtPassword.text = ""
            
            // I have successfully logged in  go to Dashboard
            self!.performSegue(withIdentifier: "loginSegue", sender: strongSelf)
            
            
            
        }
        
    }
    
    @IBAction func logoutAction(_ sender: Any) {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
            self.navigationController?.popViewController(animated: true)
        }
        catch let signOutError as NSError {
          print ("Error signing out: %@", signOutError)
            lblStatus.text = signOutError.localizedDescription
        }

        
    }
    
    @IBAction func CreateUser(_ sender: UIButton) {
        showTextInputPrompt(withMessage: "Email:") {  [weak self] userPressedOK, email in
          guard let strongSelf = self else { return }
          guard let email = email else {
            strongSelf.showMessagePrompt("email can't be empty")
            return
          }
          strongSelf.showTextInputPrompt(withMessage: "Password:")
          { userPressedOK, password in
            guard let password = password else
            {
              strongSelf.showMessagePrompt("password can't be empty")
              return
            }
            strongSelf.showSpinner {
                
              // create user account
              Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
                strongSelf.hideSpinner {
                  guard let user = authResult?.user, error == nil else {
                    strongSelf.showMessagePrompt(error!.localizedDescription)
                    return
                  }
                  print("\(user.email!) created")
                  strongSelf.navigationController?.popViewController(animated: true)
                }
              }
                
            }
          }
        }
    }
    
    @IBAction func resetPasswordAction(_ sender: Any) {
        let email = txtEmail.text
        
        if !email!.isEmail {
            lblStatus.text = "Please enter valid email"
            return
        }
        
        Auth.auth().sendPasswordReset(withEmail: email!) { error in
            if error != nil {
                self.lblStatus.text = "Sorry, reset failed"
            } else {
                self.lblStatus.text = "Check your email for link"
            }
        }
    }
    
}

